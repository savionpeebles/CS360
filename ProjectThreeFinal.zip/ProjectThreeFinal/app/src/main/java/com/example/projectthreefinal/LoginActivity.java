package com.example.projectthreefinal;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    // Declare views
    private EditText editTextUsername;
    private EditText editTextPassword;
    private TextView textViewError;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login); // Set layout file

        // Initialize views by their IDs
        editTextUsername = findViewById(R.id.editTextUsername);
        editTextPassword = findViewById(R.id.editTextPassword);
        Button buttonLogin = findViewById(R.id.buttonLogin);
        Button buttonNewUser = findViewById(R.id.buttonNewUser);
        textViewError = findViewById(R.id.textViewError);

        // Handle "Login" button click
        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = editTextUsername.getText().toString().trim();
                String password = editTextPassword.getText().toString().trim();

                // Basic validation example
                if (username.equals("admin") && password.equals("1234")) {
                    textViewError.setVisibility(View.INVISIBLE);
                    // Add successful login behavior here (e.g., open new activity)
                } else {
                    textViewError.setVisibility(View.VISIBLE);
                    textViewError.setText("The username and password are incorrect.");
                }
            }
        });

        // Handle "New User" button click
        buttonNewUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Behavior for new user registration (e.g., navigate to a new screen)
                textViewError.setVisibility(View.INVISIBLE);
                // You can start another activity or perform other actions here
            }
        });
    }
}
