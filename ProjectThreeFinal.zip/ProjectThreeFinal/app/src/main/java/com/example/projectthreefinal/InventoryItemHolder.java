package com.example.projectthreefinal;

public class InventoryItemHolder {
}
