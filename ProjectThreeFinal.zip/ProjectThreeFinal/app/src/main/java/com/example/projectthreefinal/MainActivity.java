package com.example.projectthreefinal;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ItemAdapter adapter;
    private List<String> itemList; // Data source for RecyclerView
    private TextView textViewNoItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize Views
        recyclerView = findViewById(R.id.item_grid_recycler_view);
        FloatingActionButton addButton = findViewById(R.id.add_item_button);
        textViewNoItems = findViewById(R.id.textViewNoItems);

        // Initialize item list
        itemList = new ArrayList<>();

        // Setup RecyclerView
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2)); // 2 columns grid layout
        adapter = new ItemAdapter(itemList);
        RecyclerView.Adapter itemAdapter = null;
        recyclerView.setAdapter(itemAdapter);

        // Check empty state initially
        toggleEmptyState();

        // Add button click listener
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addNewItem();
            }
        });
    }

    // Adds a new item to the list
    private void addNewItem() {
        int newItemNumber = itemList.size() + 1;
        itemList.add("Item " + newItemNumber); // Add a new item
        adapter.notifyItemInserted(itemList.size() - 1);
        toggleEmptyState();
    }

    // Toggle visibility of RecyclerView and "No Items" TextView
    private void toggleEmptyState() {
        if (itemList.isEmpty()) {
            textViewNoItems.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.GONE);
        } else {
            textViewNoItems.setVisibility(View.GONE);
            recyclerView.setVisibility(View.VISIBLE);
        }
    }
}
