package com.example.projectthreefinal;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class ItemAdapter extends AppCompatActivity {

    private TextView textViewQuantity;

    private int itemQuantity = 0; // Starting quantity

    public ItemAdapter(List<String> itemList) {
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recycle_view_items); // Attach the XML layout file

        // Initialize UI components
        // Declare UI components
        ImageButton buttonMinus = findViewById(R.id.imageButtonMinus);
        ImageButton buttonPlus = findViewById(R.id.imageButtonPlus);
        ImageButton buttonDelete = findViewById(R.id.imageButtonDelete);
        TextView textViewName = findViewById(R.id.nameText);
        textViewQuantity = findViewById(R.id.quantityText);

        // Set initial values
        textViewName.setText("Example Item");
        updateQuantityText();

        // Add functionality to "Minus" button
        buttonMinus.setOnClickListener(v -> {
            if (itemQuantity > 0) {
                itemQuantity--;
                updateQuantityText();
            } else {
                Toast.makeText(ItemAdapter.this, "No items left to remove.", Toast.LENGTH_SHORT).show();
            }
        });

        // Add functionality to "Plus" button
        buttonPlus.setOnClickListener(v -> {
            itemQuantity++;
            updateQuantityText();
        });

        // Add functionality to "Delete" button
        buttonDelete.setOnClickListener(v -> {
            itemQuantity = 0; // Reset quantity
            updateQuantityText();
            Toast.makeText(ItemAdapter.this, "Item deleted.", Toast.LENGTH_SHORT).show();
        });
    }

    // Method to update quantity text
    @SuppressLint("DefaultLocale")
    private void updateQuantityText() {
        textViewQuantity.setText(String.format("%d items in stock", itemQuantity));
    }

    public void notifyItemInserted(int i) {
    }
}